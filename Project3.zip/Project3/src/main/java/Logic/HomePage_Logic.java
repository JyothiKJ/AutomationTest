package Logic;


import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.github.javafaker.Faker;
import com.github.javafaker.IdNumber;
import com.github.javafaker.Number;
import com.github.javafaker.PhoneNumber;

import static Logic.LaunchBrowsers.*;

import java.time.Duration;
import java.util.concurrent.TimeUnit;

import Pages.HomePages;

public class HomePage_Logic {
	
	
		// constructor
		public static WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(50));
		
		@Test
		 /** 1.
	     * Method to verify user navigated to practice automation testing home page by fetching current url & comparing with actual url.
		 * @throws InterruptedException 
	     */
	    public static void verifyHomePageNavigation(){
	        String homePageUrl = driver.getCurrentUrl();
	        Assert.assertEquals(homePageUrl,"http://automationpractice.com/index.php","Not navigated to homepage home page");
	        System.out.println("Home page url is: " + homePageUrl);
	        
	    }
	    
	   	    /** 2.
	     * method to verify MyAccount button is present on the home page.
	     * @throws InterruptedException 
	     */	    
	      
	    public static void navigateToMyaccountPage() throws InterruptedException {
	    	
	    	Faker faker = new Faker();
			
			
			String mail=faker.internet().emailAddress();
			
			
			//String email = firstName.toLowerCase() + "." + lastName.toLowerCase() + "@domain.com";
	    	
	    	
	    	driver.findElement(HomePages.objContactUs);
	    	driver.findElement(HomePages.objContactUs).click();
	    	
	    	Thread.sleep(2000);	    	
	    	    	
	    	wait.until(ExpectedConditions.presenceOfElementLocated(HomePages.objHeading));
	    	driver.findElement(HomePages.objCust_service).click();
	    		    		    	    	
	    	driver.findElement(HomePages.objemail).sendKeys(mail);
	    	driver.findElement(HomePages.objOrderRef).sendKeys("orderNo");
	    	
	    	driver.findElement(HomePages.objMessage);
	    	driver.findElement(HomePages.objMessage).sendKeys("message to customersevice");
	    	
	    	Thread.sleep(2000);
	    	
	    	driver.findElement(HomePages.objChooseFile);
	    	driver.findElement(HomePages.objChooseFile).sendKeys("C:\\Users\\User\\Desktop\\XPATH.txt");

	    	driver.findElement(HomePages.objSend);
	    	driver.findElement(HomePages.objSend).click();
	    	
	   
	        	    	
	    	}
	    @Test
	    /** 3.
		    * method to verify that the successful message has been sent
		    */
		    public static void verifySuccessfullMessage()
		    {	
		    	String expectedSuccessMsg = "Your message has been successfully sent to our team.";
		    	String actualSuccessMsg =  driver.findElement(HomePages.objSuccessMsg).getText();
		    	System.out.println(actualSuccessMsg);
		    	
		    	Assert.assertEquals(actualSuccessMsg, expectedSuccessMsg,"csagxiugcxkagcxis");
		    	System.out.println("TEST PASSED - - Message has been verified successfully");
		    	
		    	
		    }
	    
	    
		    
		    
	    
}


/*package Logic;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import static Logic.LaunchBrowsers.*;

import java.time.Duration;

import Pages.HomePages;

public class VootHomePageLogic {
	// constructor
	public static WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(50));
	 /** 1.
     * Method to verify user navigated to voot home page by fetching current url & comparing with actual url.
     */
   /* public static void verifyHomePageNavigation(){
        String homePageUrl = driver.getCurrentUrl();
        Assert.assertEquals(homePageUrl,"https://www.voot.com/","Not navigated to Voot home page");
        System.out.println("Home page url is: " + homePageUrl);
    }

    /** 2.
     * method to verify voot logo by presence of element and comparing fetched logo text with actual text.
     */
    /*public static void verifyVootLogo(){
        WebElement vootlogo = driver.findElement(HomePages.objVootLogo);
        String logoText = vootlogo.getAttribute("title");
        String title = driver.getTitle();
        System.out.println("Title is: " + title);
        System.out.println("Text of voot logo is: " + logoText);
        Assert.assertEquals(logoText,"Voot","Failed to fetch voot logo");
        Assert.assertTrue(vootlogo.isDisplayed(), "Voot logo not displayed");

    }
    public static void navigateToPremiumpage() {
    	driver.findElement(HomePages.objPremiumTab);
    	driver.findElement(HomePages.objPremiumTab).click();
    	wait.until(ExpectedConditions.presenceOfElementLocated(HomePages.objCarouselCardOnPremiumTab));
    	
    }

}*/

