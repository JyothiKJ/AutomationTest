package Pages;
import org.openqa.selenium.By;

public class HomePages {
	
	public static By objContactUs = By.xpath("//a[@title='Contact Us']");
	public static By objHeading	= By.xpath("//select[@id='id_contact']");
	public static By objCust_service = By.xpath("//select[@id='id_contact']/option[@value='2']");
	public static By objWebMaster = By.xpath("//select[@id='id_contact']/option[@value='1']");
	public static By objemail = By.xpath("//input[@id='email']");
	public static By objOrderRef = By.xpath("//input[@id='id_order']");
	public static By objMessage = By.xpath("//textarea[@id='message']");
	public static By objChooseFile = By.xpath("//input[@id='fileUpload']");
	public static By objSend =  By.xpath("//button[@id='submitMessage']/span[text()='Send']");
	public static By objSuccessMsg =  By.xpath("//p[@class='alert alert-success' and contains(text(),'Your message has been successfully sent to our team.')]");
}
