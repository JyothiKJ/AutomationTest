import org.testng.annotations.Test;

import Logic.HomePage_Logic;
import Logic.LaunchBrowsers;


/* public class VootHome extends LaunchBrowsers {
	 /**
     * Method to verify UI element in voot home page
     */
 /*   @Test
    public void homePagevalidation(){
        VootHomePageLogic.verifyHomePageNavigation();
        VootHomePageLogic.verifyVootLogo();
        VootHomePageLogic.navigateToPremiumpage();
    }

} */

public class CallHomePage extends LaunchBrowsers {
	
	@Test
	/**
     * Method to verify UI element in Automation Practice home page
     */
       public void homePagevalidation() throws InterruptedException
	{
		HomePage_Logic.verifyHomePageNavigation();
        
        HomePage_Logic.navigateToMyaccountPage();
        
        HomePage_Logic.verifySuccessfullMessage();
		
       
        
    }
}
